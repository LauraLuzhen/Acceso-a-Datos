package com.ejemplo.crudalumnos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.ejemplo.crudalumnos.model.Alumno;
import com.ejemplo.crudalumnos.repository.AlumnoRepository;

import java.util.List;
import java.util.Optional;

// Imports para la ACT3
import com.ejemplo.crudalumnos.dto.AlumnoDTO;
import jakarta.validation.Valid;

// Imports para la ACT4
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/alumnos")
@Tag(name = "Alumnos", description = "Operaciones CRUD de alumnos")
public class AlumnoController {

    @Autowired
    private AlumnoRepository repo;

    // READ: Listar todos
    @Operation(summary = "Listar alumnos", description = "Obtiene todos los alumnos")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Alumno> listar() {
        return repo.findAll();
    }

    // READ: Buscar por ID
    @Operation(summary = "Buscar alumno por ID")
    @ApiResponse(responseCode = "200", description = "Alumno encontrado")
    @ApiResponse(responseCode = "404", description = "Alumno no encontrado")
    @GetMapping("/{id}")
    public ResponseEntity<Alumno> buscarPorId(@PathVariable Long id) {
        Optional<Alumno> alumno = repo.findById(id);
        return alumno.map(ResponseEntity::ok)
                      .orElse(ResponseEntity.notFound().build());
    }

    // CREATE: Crear alumno para la ACT3 con validaciones
    @Operation(summary = "Crear alumno")
    @ApiResponse(responseCode = "201", description = "Alumno creado")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    @PostMapping
    public ResponseEntity<Alumno> crear(@Valid @RequestBody AlumnoDTO dto) {

        Alumno alumno = new Alumno();
        alumno.setNombre(dto.getNombre());
        alumno.setEmail(dto.getEmail());

        Alumno creado = repo.save(alumno);

        return ResponseEntity.status(201).body(creado);
    }

    // UPDATE: Actualizar alumno
    @Operation(summary = "Actualizar alumno")
    @ApiResponse(responseCode = "200", description = "Actualizado")
    @ApiResponse(responseCode = "404", description = "No encontrado")
    @PutMapping("/{id}")
    public ResponseEntity<Alumno> actualizar(@PathVariable Long id, @RequestBody Alumno alumnoDetalles) {
        Optional<Alumno> optionalAlumno = repo.findById(id);
        if (!optionalAlumno.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Alumno alumno = optionalAlumno.get();
        alumno.setNombre(alumnoDetalles.getNombre());
        alumno.setEmail(alumnoDetalles.getEmail());
        Alumno actualizado = repo.save(alumno);
        return ResponseEntity.ok(actualizado);
    }

    // DELETE: Eliminar alumno
    @Operation(summary = "Eliminar alumno")
    @ApiResponse(responseCode = "204", description = "Eliminado")
    @ApiResponse(responseCode = "404", description = "No encontrado")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}