package com.ejemplo.crudalumnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAlumnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
