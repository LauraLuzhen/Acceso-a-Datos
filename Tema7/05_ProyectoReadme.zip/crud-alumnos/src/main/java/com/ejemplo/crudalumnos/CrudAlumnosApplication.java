package com.ejemplo.crudalumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Importaciones para la ACT4
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@OpenAPIDefinition(
		info = @Info(
				title = "API CRUD Alumnos",
				version = "1.0",
				description = "API REST para gestión de alumnos"
	    )
)
@SpringBootApplication
public class CrudAlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudAlumnosApplication.class, args);
	}

}
