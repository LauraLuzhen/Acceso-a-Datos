package com.ejemplo.crudalumnos.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

// Importaciones para la ACT4
import io.swagger.v3.oas.annotations.media.Schema;

public class AlumnoDTO {

	@Schema(description = "Email del alumno", example = "juan@email.com")
	@NotNull(message = "Email requerido")
	@NotBlank(message = "Email no vacío")
	@Email(message = "Formato inválido")
    private String email;

	@Schema(description = "Nombre del alumno", example = "Juan Pérez")
	@NotBlank(message = "Nombre obligatorio")
    private String nombre;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}