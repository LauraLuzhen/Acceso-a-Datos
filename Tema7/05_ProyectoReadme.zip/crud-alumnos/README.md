# Sistema de Gestión de Alumnos – API REST con Spring Boot

## Descripción del proyecto
Este proyecto consiste en el desarrollo de una API REST para la gestión de alumnos utilizando Spring Boot. La aplicación implementa operaciones CRUD completas, autenticación básica con Spring Security, validación de datos de entrada y documentación automática mediante OpenAPI/Swagger.
El objetivo principal del proyecto es demostrar la aplicación de buenas prácticas en el desarrollo backend moderno, incluyendo separación por capas (Controller, Service, Repository), validaciones robustas, manejo global de errores y documentación profesional de la API. El sistema está diseñado como base para aplicaciones empresariales más complejas y puede ampliarse fácilmente con nuevas funcionalidades.


## Arquitectura de la aplicación
La aplicación sigue una arquitectura en capas claramente definida:
* **Controller:** expone endpoints REST y gestiona las solicitudes HTTP.
* **Service:** contiene la lógica de negocio y coordina operaciones.
* **Repository:** maneja la persistencia de datos mediante Spring Data JPA.
* **Security Layer:** protege los endpoints con autenticación básica.
* **DTOs y validaciones:** aseguran la integridad de los datos de entrada.
* **Manejo global de errores:** centraliza las respuestas de error.


## Tecnologías utilizadas
* Java 17
* Spring Boot
* Spring Web (API REST)
* Spring Data JPA (persistencia)
* Spring Security (autenticación)
* Base de datos relacional (MySQL / H2 para desarrollo)
* Bean Validation (validación de datos)
* OpenAPI / Swagger (documentación)
* Maven (gestión de dependencias)


## Funcionalidades implementadas
### Operaciones CRUD
La API permite:
* Crear alumnos
* Obtener la lista de alumnos
* Buscar alumnos por identificador
* Actualizar información existente
* Eliminar registros

### Validación de datos
Se aplican validaciones automáticas sobre los campos obligatorios:
* El nombre del alumno no puede estar vacío
* El email debe tener un formato válido

### Seguridad
Todos los endpoints están protegidos mediante autenticación HTTP Basic. Solo los usuarios autenticados pueden acceder a los recursos de la API.

### Documentación interactiva
La documentación de la API se genera automáticamente con Swagger/OpenAPI. Permite explorar y ejecutar endpoints directamente desde el navegador.


## Requisitos previos
Antes de ejecutar el proyecto es necesario disponer de:
* Java 17 o superior
* Maven 3.8+
* MySQL (opcional si se usa H2 en memoria)
* Git


## Credenciales de acceso
Usuario: `admin`
Contraseña: `1234`


## Documentación de la API
La documentación Swagger está disponible en:
http://localhost:8080/swagger-ui.html
Desde esta interfaz se pueden consultar los endpoints, ver ejemplos de solicitudes y ejecutar operaciones directamente.


## Autor
Laura Luzhen Rodríguez Morán
