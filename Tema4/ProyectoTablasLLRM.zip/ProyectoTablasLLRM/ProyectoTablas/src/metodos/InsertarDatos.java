package metodos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import ejercicio.Indices;

public class InsertarDatos {

	static Scanner reader = new Scanner(System.in);

	public static void insertar(Connection conn) {
		int opcion = 0;

		do {
			Indices.MenuInsertarDatos();
			opcion = reader.nextInt();
			reader.nextLine();

			switch (opcion) {
			case 1 -> {
				// Insertar en Player
				try {
					System.out.print("Nick: ");
					String nick = reader.nextLine();

					System.out.print("Password: ");
					String password = reader.nextLine();

					System.out.print("Email: ");
					String email = reader.nextLine();

					String sql = "INSERT INTO Player (Nick, Password, Email) VALUES (?, ?, ?)";
					try (PreparedStatement ps = conn.prepareStatement(sql)) {
						ps.setString(1, nick);
						ps.setString(2, password);
						ps.setString(3, email);
						ps.executeUpdate();
						System.out.println("Player insertado correctamente");
					}
				} catch (SQLException e) {
					System.out.println("Error: " + e.getMessage());
				}
			}
			case 2 -> {
				// Insertar en Compras
				try {
					System.out.print("Player ID: ");
					int idPlayer = reader.nextInt();
					reader.nextLine();

					System.out.print("Games ID: ");
					int idGames = reader.nextInt();
					reader.nextLine();

					if (Existe.existePorId("Player", "idPlayer", idPlayer, conn)
							&& Existe.existePorId("Games", "idGames", idGames, conn)) {

						System.out.print("Cosa: ");
						String cosa = reader.nextLine();

						System.out.print("Precio: ");
						double precio = reader.nextDouble();
						reader.nextLine();
						
						System.out.println("Fecha compra: ");
						String fechaCompra = reader.nextLine();

						String sql = "INSERT INTO Compras (idPlayer, idGames, Cosa, Precio, FechaCompra) VALUES (?, ?, ?, ?, ?)";
						try (PreparedStatement ps = conn.prepareStatement(sql)) {
							ps.setInt(1, idPlayer);
							ps.setInt(2, idGames);
							ps.setString(3, cosa);
							ps.setDouble(4, precio);
							ps.setString(5, fechaCompra);
							ps.executeUpdate();
							System.out.println("Comrpas insertada correctamente");
						}
					} else {
						System.err.println("No existe Player o Games ID.");
					}
				} catch (SQLException e) {
					System.out.println("Error: " + e.getMessage());
				}
			}
			case 3 -> {
				// Insertar en Games
				try {
					System.out.print("Nombre: ");
					String nombre = reader.nextLine();

					System.out.print("Tiempo jugado: ");
					String tiempoJugado = reader.nextLine();

					String sql = "INSERT INTO Games (Nombre, tiempoJugado) VALUES (?, ?)";
					try (PreparedStatement ps = conn.prepareStatement(sql)) {
						ps.setString(1, nombre);
						ps.setString(2, tiempoJugado);
						ps.executeUpdate();
						System.out.println("Games insertado correctamente");
					}
				} catch (SQLException e) {
					System.out.println("Error: " + e.getMessage());
				}
			}
			case 4 -> System.out.println("Saliendo de insertar datos...");
			default -> System.out.println("Opción no válida");
			}
		} while (opcion != 4);
	}
}
