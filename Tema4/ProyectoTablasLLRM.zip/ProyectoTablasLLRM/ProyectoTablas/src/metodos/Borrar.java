package metodos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import ejercicio.Indices;

public class Borrar {
	
	static Scanner reader = new Scanner(System.in);

	public static void borrar(Connection conn) {
		Indices.MenuBorrar();
        int op = reader.nextInt();
        reader.nextLine();

        String tabla = switch (op) {
            case 1 -> "Player";
            case 2 -> "Compras";
            case 3 -> "Games";
            default -> null;
        };

        if (tabla == null) return;
        System.out.print("Introduce el ID: ");
        int id = reader.nextInt();
        reader.nextLine();

        String sql = "DELETE FROM " + tabla + " WHERE id" + tabla + "=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Registro borrado");
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
