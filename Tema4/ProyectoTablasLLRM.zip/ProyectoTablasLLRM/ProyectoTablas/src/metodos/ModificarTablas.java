package metodos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import ejercicio.Indices;

public class ModificarTablas {
	
	static Scanner reader = new Scanner(System.in);

	public static void modificar(Connection conn) {
        Indices.MenuModificarTablas();
        int op = reader.nextInt();
        reader.nextLine();
        
        String tabla = switch (op) {
        case 1 -> "Player";
        case 2 -> "Compras";
        case 3 -> "Games";
        default -> null;
    };
        
        if (tabla == null) return;

        System.out.print("Introduce el ID: ");
        int id = reader.nextInt();
        reader.nextLine();

        if (Existe.existePorId(tabla, "id" + tabla.substring(0,1).toUpperCase() + tabla.substring(1), id, conn)) {
	        System.out.print("Campo a modificar: ");
	        String campo = reader.nextLine();
	
	        System.out.print("Nuevo valor: ");
	        String valor = reader.nextLine();
	
	        String sql = "UPDATE " + tabla + " SET " + campo + "=? WHERE id" + tabla + "=?";
	
	        try (PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setString(1, valor);
	            ps.setInt(2, id);
	            ps.executeUpdate();
	            System.out.println("Modificado correctamente!");
	        } catch (SQLException e) {
	            System.out.println("Error: " + e.getMessage());
	        }
        } else {
        	System.err.println("No existe ese ID");
        }
    }
}
