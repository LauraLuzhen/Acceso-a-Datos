package metodos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import ejercicio.Indices;

public class ListarTablas {

	static Scanner reader = new Scanner(System.in);

	public static void listar(Connection conn) {
		String sql = "";
		int opc = 0;

		try {
			Indices.MenuListarTablas();
			opc = reader.nextInt();
			reader.nextLine();

			switch (opc) {
			case 1 -> sql = "SELECT * FROM Player";
			case 2 -> sql = "SELECT * FROM Compras";
			case 3 -> sql = "SELECT * FROM Games";
			}
			try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
				int columnas = rs.getMetaData().getColumnCount();
				System.out.println("\n-----LISTADO-----");
				while (rs.next()) {
					for (int i = 1; i <= columnas; i++) {
						System.out.print(rs.getString(i) + "\t");
					}
					System.out.println();
				}
			}
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}
}
