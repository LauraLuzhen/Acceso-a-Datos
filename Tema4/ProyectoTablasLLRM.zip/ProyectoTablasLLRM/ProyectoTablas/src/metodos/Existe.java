package metodos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Existe {

	public static boolean existeTabla(String nombreTabla, Connection conn) {
		boolean existe = false;
	    try (ResultSet rs = conn.getMetaData().getTables(null, null, nombreTabla, null)) {
	        existe = rs.next();
	    } catch (SQLException e) {
	        existe = false;
	    }
	    return existe;
	}
	
	public static boolean existePorId(String tabla, String campoId, int id, Connection conn) {
	    String sql = "SELECT 1 FROM " + tabla + " WHERE " + campoId + " = ?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, id);
	        try (ResultSet rs = ps.executeQuery()) {
	            return rs.next();
	        }
	    } catch (SQLException e) {
	        System.err.println("Error al comprobar existencia en " + tabla + ": " + e.getMessage());
	        return false;
	    }
	}
}
