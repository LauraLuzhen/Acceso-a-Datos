package metodos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class EliminarTablas {
	
	static Scanner reader = new Scanner(System.in);

	public static void eliminar(Connection conn) {
        try (Statement st = conn.createStatement()) {

            st.execute("DROP TABLE IF EXISTS Compras");
            st.execute("DROP TABLE IF EXISTS Player");
            st.execute("DROP TABLE IF EXISTS Games");

            System.out.println("Tablas eliminadas");
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
