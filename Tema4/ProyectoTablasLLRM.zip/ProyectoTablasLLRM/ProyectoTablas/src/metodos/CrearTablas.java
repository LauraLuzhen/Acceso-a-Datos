package metodos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import ejercicio.Indices;


public class CrearTablas {

	static Scanner reader = new Scanner(System.in);
	
	public static void crear(Connection conn) {
        String sql = "";
        int opcion = 0;
        
        do {
        	Indices.MenuCrearTablas();
        	opcion = reader.nextInt();
            
            try (Statement statement = conn.createStatement()) {
                
            	switch (opcion) {
                case 1 -> {	
                	// Crear tabla Player
                    sql = """
                        CREATE TABLE IF NOT EXISTS Player (
                            idPlayer INT AUTO_INCREMENT PRIMARY KEY,
                            Nick VARCHAR(45),
                            password VARCHAR(128),
                            email VARCHAR(100)
                        );
                    """;
                    statement.execute(sql);
                    System.out.println("Tabla Player creada");
                }
                case 2 -> {
                    // Crear tabla Compras comprobando que existen Player y Games
                    if (Existe.existeTabla("Player", conn) && Existe.existeTabla("Games", conn)) {
                        sql = """
                            CREATE TABLE IF NOT EXISTS Compras (
                                idCompra INT AUTO_INCREMENT PRIMARY KEY,
                                idPlayer INT,
                                idGames INT,
                                Cosa VARCHAR(25),
                                Precio DECIMAL(6,2),
                                FechaCompra DATE,
                                FOREIGN KEY (idPlayer) REFERENCES Player(idPlayer),
                                FOREIGN KEY (idGames) REFERENCES Games(idGames)
                            );
                        """;
                        statement.execute(sql);
                        System.out.println("Tabla Compras creada.");
                    } else {
                        System.out.println("No existe la tabla Player o Games. Crea primero ambas.");
                    }
                }
                case 3 -> {
                	// Crea tabla Games
                    sql = """
                        CREATE TABLE IF NOT EXISTS Games (
                            idGames INT AUTO_INCREMENT PRIMARY KEY,
                            Nombre VARCHAR(45),
                            tiempoJugado TIME
                        );
                    """;
                    statement.execute(sql);
                    System.out.println("Tabla Games creada");
                }
                case 4 -> {
                    // Creamos todas las tablas
                    statement.execute("""
                        CREATE TABLE IF NOT EXISTS Player (
                            idPlayer INT AUTO_INCREMENT PRIMARY KEY,
                            Nick VARCHAR(45),
                            password VARCHAR(128),
                            email VARCHAR(100)
                        );
                    """);

                    statement.execute("""
                        CREATE TABLE IF NOT EXISTS Games (
                            idGames INT AUTO_INCREMENT PRIMARY KEY,
                            Nombre VARCHAR(45),
                            tiempoJugado TIME
                        );
                    """);

                    statement.execute("""
                        CREATE TABLE IF NOT EXISTS Compras (
                            idCompra INT AUTO_INCREMENT PRIMARY KEY,
                            idPlayer INT,
                            idGames INT,
                            Cosa VARCHAR(25),
                            Precio DECIMAL(6,2),
                            FechaCompra DATE,
                            FOREIGN KEY (idPlayer) REFERENCES Player(idPlayer),
                            FOREIGN KEY (idGames) REFERENCES Games(idGames)
                        );
                    """);

                    System.out.println("Las tres tablas han sido creadas");
                }
                case 5 -> System.out.println("Saliendo de crear tablas...");
                default -> System.out.println("Opción no válida");
            	}
                
            } catch (SQLException e) {
                System.err.println("Error: " + e.getMessage());
            }
        } while(opcion != 5);
    }
	
	
}
