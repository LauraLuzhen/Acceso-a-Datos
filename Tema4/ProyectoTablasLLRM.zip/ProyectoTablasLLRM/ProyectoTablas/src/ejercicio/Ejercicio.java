package ejercicio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

import metodos.Borrar;
import metodos.CrearTablas;
import metodos.EliminarTablas;
import metodos.InsertarDatos;
import metodos.ListarTablas;
import metodos.ModificarTablas;

public class Ejercicio {

	// Scanner
	static Scanner reader = new Scanner(System.in);
	// Url
	static String url = "jdbc:mysql://dns11036.phdns11.es:3306/ad2526_laura_luzhen";
	// Usuario
	static String user = "ad2526_laura_luzhen";
	// Contraseña
	static String password = "12345";
	// Conexión
	static Connection conn;

	public static void main(String[] args) {
		int opcion = 0;
		
		do {
			Indices.MenuPrincipal();
			opcion = reader.nextInt();
			reader.nextLine();

			switch (opcion) {
			case 1 -> {
				conectar(url, user, password);
			}
			case 2 -> {
				if (conn != null) {
					CrearTablas.crear(conn);
				} else {
					System.out.println("Conectate primero a la BBDD");
				}
			}
			case 3 -> {
				if (conn != null) {
					InsertarDatos.insertar(conn);
				} else {
					System.out.println("Conectate primero a la BBDD");
				}			}
			case 4 -> {
				if (conn != null) {
					ListarTablas.listar(conn);
				} else {
					System.out.println("Conectate primero a la BBDD");
				}
			}
			case 5 -> {
				if (conn != null) {
					ModificarTablas.modificar(conn);
				} else {
					System.out.println("Conectate primero a la BBDD");
				}
			}
			case 6 -> {
				if (conn != null) {
					Borrar.borrar(conn);
				} else {
					System.out.println("Conectate primero a la BBDD");
				}
			}
			case 7 -> {
				if (conn != null) {
					EliminarTablas.eliminar(conn);
				} else {
					System.out.println("Conectate primero a la BBDD");
				}
			}
			case 8 -> System.out.println("Saliendo...");
			default -> System.out.println("Opción no válida");
			}
		} while (opcion != 8);
	}

	/**
	 * Conexión a la bbdd
	 * 
	 * @param url
	 * @param usuario
	 * @param contrasena
	 */
	public static void conectar(String url, String user, String pswd) {
		try {
			conn = DriverManager.getConnection(url, user, pswd);
			System.out.println("Conexion exitosa!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
