package modelos;

import jakarta.persistence.*;

@Entity
@Table(name = "Player")
public class Player {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idPlayer")
    private int idPlayer;
    
    @Column(name = "Nick", length = 45)
    private String nick;
    
    @Column(name = "password", length = 128)
    private String password;
    
    @Column(name = "email", length = 100)
    private String email;
    
    // Constructor vacío (obligatorio para Hibernate)
    public Player() {}
    
    // Constructor con parámetros
    public Player(String nick, String password, String email) {
        this.nick = nick;
        this.password = password;
        this.email = email;
    }
    
    // Getters y Setters
    public int getIdPlayer() {
        return idPlayer;
    }
    
    public void setIdPlayer(int idPlayer) {
        this.idPlayer = idPlayer;
    }
    
    public String getNick() {
        return nick;
    }
    
    public void setNick(String nick) {
        this.nick = nick;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public String toString() {
        return "Player [idPlayer=" + idPlayer + ", nick=" + nick + ", email=" + email + "]";
    }
}