package indices;

public class Indices {

	public static void MenuPrincipal() {
		System.out.println("ELIGE UNA OPCIÓN:");
		System.out.println("1) Conexión a la BBDD");
		System.out.println("2) Crear tablas");
		System.out.println("3) Insertar datos");
		System.out.println("4) Listar");
		System.out.println("5) Modificar");
		System.out.println("6) Borrar datos");
		System.out.println("7) Eliminar tablas");
		System.out.println("8) Salir");
	}
	
	public static void MenuCrearTablas() {
        System.out.println("ELIGE QUÉ TABLA QUIERES CREAR: ");
        System.out.println("1) Player");
        System.out.println("2) Compras");
        System.out.println("3) Games");
        System.out.println("4) Todas");
        System.out.println("5) Salir");
	}
	
	public static void MenuInsertarDatos() {
		System.out.println("ELIGE QUÉ TABLA QUIERES PARA INSERTAR DATOS: ");
		System.out.println("1) Player");
		System.out.println("2) Compras");
		System.out.println("3) Games");
		System.out.println("4) Salir");
	}
	
	public static void MenuListarTablas() {
        System.out.println("ELIGE LA TABLA QUE QUIERAS LISTAR: ");
        System.out.println("1) Player");
        System.out.println("2) Compras");
        System.out.println("3) Games");
        System.out.println("4) Todas");
        System.out.println("5) Salir");
	}
	
	public static void MenuModificarDatos() {
        System.out.println("ELIGE QUÉ TABLA QUIERES MODIFICAR: ");
        System.out.println("1) Player");
        System.out.println("2) Compras");
        System.out.println("3) Games");
        System.out.println("4) Salir");
	}
	
	public static void MenuBorrarDatos() {
        System.out.println("ELIGE DE QUÉ TABLA DESEAS BORRAR: ");
        System.out.println("1) Player");
        System.out.println("2) Compras");
        System.out.println("3) Games");
        System.out.println("4) Salir");
	}
	
	public static void MenuEliminarTablas() {
		System.out.println("ELIGE QUÉ TABLA ELIMINAR: ");
		System.out.println("1) Player");
		System.out.println("2) Games");
		System.out.println("3) Compras");
		System.out.println("4) Todas");
		System.out.println("5) Salir");
	}
}
