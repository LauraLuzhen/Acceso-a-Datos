package operaciones;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import aplicacion.App;
import indices.Indices;
import modelos.Compras;
import modelos.Games;
import modelos.Player;

public class BorrarDatos {
    
    public static void ejecutar(Scanner reader) {
        int opcion = 0;
        
        do {
            Indices.MenuBorrarDatos();
            opcion = reader.nextInt();
            reader.nextLine();
            
            switch (opcion) {
                case 1:
                    borrarPlayer(reader);
                    break;
                case 2:
                    borrarCompras(reader);
                    break;
                case 3:
                    borrarGames(reader);
                    break;
                case 4:
                    System.out.println("Saliendo de borrar datos...");
                    break;
                default:
                    System.out.println("❌ Opción no válida");
                    break;
            }
            
        } while (opcion != 4);
    }
    
    // =============== BORRAR PLAYER ===============
    private static void borrarPlayer(Scanner reader) {
        if (!existeTabla("Player")) {
            System.out.println("❌ La tabla Player no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Mostrar todos los players
            System.out.println("\n========== PLAYERS DISPONIBLES ==========");
            List<Player> todosPlayers = session.createQuery("FROM Player", Player.class).list();
            
            if (todosPlayers.isEmpty()) {
                System.out.println("❌ No hay jugadores registrados");
                return;
            }
            
            for (Player p : todosPlayers) {
                System.out.println(p);
            }
            System.out.println("=========================================\n");
            
            System.out.println("¿Qué quieres borrar?");
            System.out.println("1) Todos los datos");
            System.out.println("2) Filtrado");
            System.out.print("Opción: ");
            int tipoBorrado = reader.nextInt();
            reader.nextLine();
            
            transaction = session.beginTransaction();
            List<Player> playersABorrar = null;
            
            if (tipoBorrado == 1) {
                // Borrar todos
                playersABorrar = todosPlayers;
                
            } else if (tipoBorrado == 2) {
                // Borrar con filtro
                System.out.println("\nCAMPOS DISPONIBLES PARA FILTRAR:");
                System.out.println("1) Nick");
                System.out.println("2) Email");
                System.out.print("Elige el campo: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                String nombreCampo = switch (campo) {
                    case 1 -> "nick";
                    case 2 -> "email";
                    default -> null;
                };
                
                if (nombreCampo == null) {
                    System.out.println("❌ Campo no válido");
                    return;
                }
                
                System.out.println("\nTIPO DE FILTRO:");
                System.out.println("1) = (igual)");
                System.out.println("2) LIKE %contenido%");
                System.out.println("3) < (menor que)");
                System.out.println("4) > (mayor que)");
                System.out.print("Opción: ");
                int tipoFiltro = reader.nextInt();
                reader.nextLine();
                
                System.out.print("Valor a buscar: ");
                String valor = reader.nextLine();
                
                String hql = construirHQL("Player", nombreCampo, tipoFiltro, valor, false);
                playersABorrar = session.createQuery(hql, Player.class).list();
            }
            
            if (playersABorrar == null || playersABorrar.isEmpty()) {
                System.out.println("❌ No se encontraron registros para borrar");
                transaction.rollback();
                return;
            }
            
            // Verificar si tienen compras asociadas
            System.out.println("\n🗑️ REGISTROS QUE SE ELIMINARÁN:");
            for (Player p : playersABorrar) {
                System.out.println(p);
                
                // Buscar compras asociadas
                List<Compras> comprasAsociadas = session.createQuery(
                    "FROM Compras WHERE idPlayer = :idPlayer", Compras.class)
                    .setParameter("idPlayer", p.getIdPlayer())
                    .list();
                
                if (!comprasAsociadas.isEmpty()) {
                    System.out.println("  ⚠️ TIENE " + comprasAsociadas.size() + " COMPRA(S) ASOCIADA(S):");
                    for (Compras c : comprasAsociadas) {
                        Games game = session.get(Games.class, c.getIdGames());
                        System.out.println("    - Compra ID: " + c.getIdCompra() + 
                                         ", Juego: " + (game != null ? game.getNombre() : "Desconocido") +
                                         ", Cosa: " + c.getCosa() + ", Precio: " + c.getPrecio());
                    }
                }
            }
            
            System.out.println("\n⚠️ ¿Estás seguro de eliminar estos " + playersABorrar.size() + " jugador(es)?");
            System.out.println("⚠️ Se eliminarán también todas sus compras asociadas");
            System.out.println("1) Sí, eliminar (COMMIT)");
            System.out.println("2) No, cancelar (ROLLBACK)");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                // Primero borrar compras asociadas
                for (Player p : playersABorrar) {
                    session.createQuery("DELETE FROM Compras WHERE idPlayer = :idPlayer")
                        .setParameter("idPlayer", p.getIdPlayer())
                        .executeUpdate();
                }
                
                // Luego borrar players
                for (Player p : playersABorrar) {
                    session.remove(p);
                }
                
                transaction.commit();
                System.out.println("✅ " + playersABorrar.size() + " jugador(es) eliminado(s) correctamente");
            } else {
                transaction.rollback();
                System.out.println("❌ Borrado cancelado (ROLLBACK)");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al borrar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== BORRAR GAMES ===============
    private static void borrarGames(Scanner reader) {
        if (!existeTabla("Games")) {
            System.out.println("❌ La tabla Games no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Mostrar todos los games
            System.out.println("\n========== GAMES DISPONIBLES ==========");
            List<Games> todosGames = session.createQuery("FROM Games", Games.class).list();
            
            if (todosGames.isEmpty()) {
                System.out.println("❌ No hay juegos registrados");
                return;
            }
            
            for (Games g : todosGames) {
                System.out.println(g);
            }
            System.out.println("=========================================\n");
            
            System.out.println("¿Qué quieres borrar?");
            System.out.println("1) Todos los datos");
            System.out.println("2) Filtrado");
            System.out.print("Opción: ");
            int tipoBorrado = reader.nextInt();
            reader.nextLine();
            
            transaction = session.beginTransaction();
            List<Games> gamesABorrar = null;
            
            if (tipoBorrado == 1) {
                // Borrar todos
                gamesABorrar = todosGames;
                
            } else if (tipoBorrado == 2) {
                // Borrar con filtro
                System.out.println("\nCAMPOS DISPONIBLES PARA FILTRAR:");
                System.out.println("1) Nombre");
                System.out.print("Elige el campo: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                System.out.println("\nTIPO DE FILTRO:");
                System.out.println("1) = (igual)");
                System.out.println("2) LIKE %contenido%");
                System.out.println("3) < (menor que)");
                System.out.println("4) > (mayor que)");
                System.out.print("Opción: ");
                int tipoFiltro = reader.nextInt();
                reader.nextLine();
                
                System.out.print("Valor a buscar: ");
                String valor = reader.nextLine();
                
                String hql = construirHQL("Games", "nombre", tipoFiltro, valor, false);
                gamesABorrar = session.createQuery(hql, Games.class).list();
            }
            
            if (gamesABorrar == null || gamesABorrar.isEmpty()) {
                System.out.println("❌ No se encontraron registros para borrar");
                transaction.rollback();
                return;
            }
            
            // Verificar si tienen compras asociadas
            System.out.println("\n🗑️ REGISTROS QUE SE ELIMINARÁN:");
            for (Games g : gamesABorrar) {
                System.out.println(g);
                
                // Buscar compras asociadas
                List<Compras> comprasAsociadas = session.createQuery(
                    "FROM Compras WHERE idGames = :idGames", Compras.class)
                    .setParameter("idGames", g.getIdGames())
                    .list();
                
                if (!comprasAsociadas.isEmpty()) {
                    System.out.println("  ⚠️ TIENE " + comprasAsociadas.size() + " COMPRA(S) ASOCIADA(S):");
                    for (Compras c : comprasAsociadas) {
                        Player player = session.get(Player.class, c.getIdPlayer());
                        System.out.println("    - Compra ID: " + c.getIdCompra() + 
                                         ", Jugador: " + (player != null ? player.getNick() : "Desconocido") +
                                         ", Cosa: " + c.getCosa() + ", Precio: " + c.getPrecio());
                    }
                }
            }
            
            System.out.println("\n⚠️ ¿Estás seguro de eliminar estos " + gamesABorrar.size() + " juego(s)?");
            System.out.println("⚠️ Se eliminarán también todas sus compras asociadas");
            System.out.println("1) Sí, eliminar (COMMIT)");
            System.out.println("2) No, cancelar (ROLLBACK)");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                // Primero borrar compras asociadas
                for (Games g : gamesABorrar) {
                    session.createQuery("DELETE FROM Compras WHERE idGames = :idGames")
                        .setParameter("idGames", g.getIdGames())
                        .executeUpdate();
                }
                
                // Luego borrar games
                for (Games g : gamesABorrar) {
                    session.remove(g);
                }
                
                transaction.commit();
                System.out.println("✅ " + gamesABorrar.size() + " juego(s) eliminado(s) correctamente");
            } else {
                transaction.rollback();
                System.out.println("❌ Borrado cancelado (ROLLBACK)");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al borrar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== BORRAR COMPRAS ===============
    private static void borrarCompras(Scanner reader) {
        if (!existeTabla("Compras")) {
            System.out.println("❌ La tabla Compras no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Mostrar todas las compras
            System.out.println("\n========== COMPRAS DISPONIBLES ==========");
            List<Compras> todasCompras = session.createQuery("FROM Compras", Compras.class).list();
            
            if (todasCompras.isEmpty()) {
                System.out.println("❌ No hay compras registradas");
                return;
            }
            
            for (Compras c : todasCompras) {
                Player player = session.get(Player.class, c.getIdPlayer());
                Games game = session.get(Games.class, c.getIdGames());
                
                System.out.println("ID Compra: " + c.getIdCompra());
                System.out.println("  Jugador: " + (player != null ? player.getNick() : "Desconocido"));
                System.out.println("  Juego: " + (game != null ? game.getNombre() : "Desconocido"));
                System.out.println("  Cosa: " + c.getCosa());
                System.out.println("  Precio: " + c.getPrecio());
                System.out.println("  Fecha: " + c.getFechaCompra());
                System.out.println("---");
            }
            System.out.println("=========================================\n");
            
            System.out.println("¿Qué quieres borrar?");
            System.out.println("1) Todos los datos");
            System.out.println("2) Filtrado");
            System.out.print("Opción: ");
            int tipoBorrado = reader.nextInt();
            reader.nextLine();
            
            transaction = session.beginTransaction();
            List<Compras> comprasABorrar = null;
            
            if (tipoBorrado == 1) {
                // Borrar todos
                comprasABorrar = todasCompras;
                
            } else if (tipoBorrado == 2) {
                // Borrar con filtro
                System.out.println("\nCAMPOS DISPONIBLES PARA FILTRAR:");
                System.out.println("1) Jugador (por Nick)");
                System.out.println("2) Juego (por Nombre)");
                System.out.println("3) Cosa");
                System.out.println("4) Precio");
                System.out.print("Elige el campo: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                if (campo == 1) {
                    // Filtrar por jugador
                    System.out.print("Nick del jugador: ");
                    String nick = reader.nextLine();
                    
                    String hql = "FROM Compras c WHERE c.idPlayer IN (SELECT p.idPlayer FROM Player p WHERE p.nick LIKE '%" + nick + "%')";
                    comprasABorrar = session.createQuery(hql, Compras.class).list();
                    
                } else if (campo == 2) {
                    // Filtrar por juego
                    System.out.print("Nombre del juego: ");
                    String nombre = reader.nextLine();
                    
                    String hql = "FROM Compras c WHERE c.idGames IN (SELECT g.idGames FROM Games g WHERE g.nombre LIKE '%" + nombre + "%')";
                    comprasABorrar = session.createQuery(hql, Compras.class).list();
                    
                } else if (campo == 3 || campo == 4) {
                    String nombreCampo = (campo == 3) ? "cosa" : "precio";
                    boolean esNumerico = (campo == 4);
                    
                    System.out.println("\nTIPO DE FILTRO:");
                    System.out.println("1) = (igual)");
                    System.out.println("2) LIKE %contenido%");
                    System.out.println("3) < (menor que)");
                    System.out.println("4) > (mayor que)");
                    System.out.print("Opción: ");
                    int tipoFiltro = reader.nextInt();
                    reader.nextLine();
                    
                    System.out.print("Valor a buscar: ");
                    String valor = reader.nextLine();
                    
                    String hql = construirHQL("Compras", nombreCampo, tipoFiltro, valor, esNumerico);
                    comprasABorrar = session.createQuery(hql, Compras.class).list();
                }
            }
            
            if (comprasABorrar == null || comprasABorrar.isEmpty()) {
                System.out.println("❌ No se encontraron registros para borrar");
                transaction.rollback();
                return;
            }
            
            // Mostrar compras que se borrarán
            System.out.println("\n🗑️ REGISTROS QUE SE ELIMINARÁN:");
            for (Compras c : comprasABorrar) {
                Player player = session.get(Player.class, c.getIdPlayer());
                Games game = session.get(Games.class, c.getIdGames());
                
                System.out.println("ID Compra: " + c.getIdCompra());
                System.out.println("  Jugador: " + (player != null ? player.getNick() : "Desconocido"));
                System.out.println("  Juego: " + (game != null ? game.getNombre() : "Desconocido"));
                System.out.println("  Cosa: " + c.getCosa());
                System.out.println("  Precio: " + c.getPrecio());
                System.out.println("  Fecha: " + c.getFechaCompra());
                System.out.println("---");
            }
            
            System.out.println("\n⚠️ ¿Estás seguro de eliminar estas " + comprasABorrar.size() + " compra(s)?");
            System.out.println("1) Sí, eliminar (COMMIT)");
            System.out.println("2) No, cancelar (ROLLBACK)");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                for (Compras c : comprasABorrar) {
                    session.remove(c);
                }
                
                transaction.commit();
                System.out.println("✅ " + comprasABorrar.size() + " compra(s) eliminada(s) correctamente");
            } else {
                transaction.rollback();
                System.out.println("❌ Borrado cancelado (ROLLBACK)");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al borrar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== CONSTRUIR HQL CON FILTROS ===============
    private static String construirHQL(String tabla, String campo, int tipoFiltro, String valor, boolean esNumerico) {
        String hql = "FROM " + tabla + " WHERE ";
        
        switch (tipoFiltro) {
            case 1: // Igual
                if (esNumerico) {
                    hql += campo + " = " + valor;
                } else {
                    hql += campo + " = '" + valor + "'";
                }
                break;
            case 2: // LIKE
                hql += campo + " LIKE '%" + valor + "%'";
                break;
            case 3: // Menor que
                if (esNumerico) {
                    hql += campo + " < " + valor;
                } else {
                    hql += campo + " < '" + valor + "'";
                }
                break;
            case 4: // Mayor que
                if (esNumerico) {
                    hql += campo + " > " + valor;
                } else {
                    hql += campo + " > '" + valor + "'";
                }
                break;
            default:
                return "FROM " + tabla;
        }
        
        return hql;
    }
    
    // =============== VERIFICAR SI EXISTE TABLA ===============
    private static boolean existeTabla(String nombreTabla) {
        Session session = null;
        try {
            session = App.sessionFactory.openSession();
            String sql = "SHOW TABLES LIKE '" + nombreTabla + "'";
            Query<?> query = session.createNativeQuery(sql, Object.class);
            List<?> result = query.list();
            return !result.isEmpty();
        } catch (Exception e) {
            return false;
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}