package operaciones;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import aplicacion.App;
import indices.Indices;
import modelos.Compras;
import modelos.Games;
import modelos.Player;

public class ModificarDatos {
    
    public static void ejecutar(Scanner reader) {
        int opcion = 0;
        
        do {
            Indices.MenuModificarDatos();
            opcion = reader.nextInt();
            reader.nextLine();
            
            switch (opcion) {
                case 1:
                    modificarPlayer(reader);
                    break;
                case 2:
                    modificarCompras(reader);
                    break;
                case 3:
                    modificarGames(reader);
                    break;
                case 4:
                    System.out.println("Saliendo de modificar datos...");
                    break;
                default:
                    System.out.println("❌ Opción no válida");
                    break;
            }
            
        } while (opcion != 4);
    }
    
    // =============== MODIFICAR PLAYER ===============
    private static void modificarPlayer(Scanner reader) {
        if (!existeTabla("Player")) {
            System.out.println("❌ La tabla Player no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Mostrar todos los players
            System.out.println("\n========== PLAYERS DISPONIBLES ==========");
            List<Player> players = session.createQuery("FROM Player", Player.class).list();
            
            if (players.isEmpty()) {
                System.out.println("❌ No hay jugadores registrados");
                return;
            }
            
            for (Player p : players) {
                System.out.println(p);
            }
            System.out.println("=========================================\n");
            
            System.out.println("¿Cómo quieres modificar?");
            System.out.println("1) Modificar por campo (masivo)");
            System.out.println("2) Modificar un jugador específico");
            System.out.print("Opción: ");
            int tipoModificacion = reader.nextInt();
            reader.nextLine();
            
            transaction = session.beginTransaction();
            int registrosModificados = 0;
            
            if (tipoModificacion == 1) {
                // Modificar por campo (masivo)
                System.out.println("\nCAMPOS DISPONIBLES:");
                System.out.println("1) Nick");
                System.out.println("2) Password");
                System.out.println("3) Email");
                System.out.print("Elige el campo a modificar: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                String nombreCampo = switch (campo) {
                    case 1 -> "nick";
                    case 2 -> "password";
                    case 3 -> "email";
                    default -> null;
                };
                
                if (nombreCampo == null) {
                    System.out.println("❌ Campo no válido");
                    return;
                }
                
                System.out.print("Valor actual a buscar: ");
                String valorAntiguo = reader.nextLine();
                
                System.out.print("Nuevo valor: ");
                String valorNuevo = reader.nextLine();
                
                String hql = "UPDATE Player SET " + nombreCampo + " = :nuevo WHERE " + nombreCampo + " = :antiguo";
                Query<?> query = session.createQuery(hql);
                query.setParameter("nuevo", valorNuevo);
                query.setParameter("antiguo", valorAntiguo);
                registrosModificados = query.executeUpdate();
                
                System.out.println("\n📝 Se modificarán " + registrosModificados + " registro(s)");
                
            } else if (tipoModificacion == 2) {
                // Modificar jugador específico
                System.out.print("\nEscribe el Nick del jugador a modificar: ");
                String nick = reader.nextLine();
                
                Player player = session.createQuery("FROM Player WHERE nick = :nick", Player.class)
                        .setParameter("nick", nick)
                        .uniqueResult();
                
                if (player == null) {
                    System.out.println("❌ No se encontró un jugador con ese nick");
                    return;
                }
                
                System.out.println("\nDatos actuales:");
                System.out.println(player);
                
                System.out.println("\n¿Qué campo quieres modificar?");
                System.out.println("1) Nick");
                System.out.println("2) Password");
                System.out.println("3) Email");
                System.out.print("Opción: ");
                int campoModificar = reader.nextInt();
                reader.nextLine();
                
                System.out.print("Nuevo valor: ");
                String nuevoValor = reader.nextLine();
                
                switch (campoModificar) {
                    case 1 -> player.setNick(nuevoValor);
                    case 2 -> player.setPassword(nuevoValor);
                    case 3 -> player.setEmail(nuevoValor);
                    default -> {
                        System.out.println("❌ Opción no válida");
                        return;
                    }
                }
                
                session.merge(player);
                registrosModificados = 1;
                
                System.out.println("\n📝 Datos modificados:");
                System.out.println(player);
            }
            
            // Confirmar o cancelar
            System.out.println("\n¿Deseas aplicar los cambios?");
            System.out.println("1) Sí (COMMIT)");
            System.out.println("2) No (ROLLBACK)");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                transaction.commit();
                System.out.println("✅ " + registrosModificados + " registro(s) modificado(s) correctamente");
            } else {
                transaction.rollback();
                System.out.println("❌ Cambios descartados (ROLLBACK)");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al modificar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== MODIFICAR GAMES ===============
    private static void modificarGames(Scanner reader) {
        if (!existeTabla("Games")) {
            System.out.println("❌ La tabla Games no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Mostrar todos los games
            System.out.println("\n========== GAMES DISPONIBLES ==========");
            List<Games> games = session.createQuery("FROM Games", Games.class).list();
            
            if (games.isEmpty()) {
                System.out.println("❌ No hay juegos registrados");
                return;
            }
            
            for (Games g : games) {
                System.out.println(g);
            }
            System.out.println("=========================================\n");
            
            System.out.println("¿Cómo quieres modificar?");
            System.out.println("1) Modificar por campo (masivo)");
            System.out.println("2) Modificar un juego específico");
            System.out.print("Opción: ");
            int tipoModificacion = reader.nextInt();
            reader.nextLine();
            
            transaction = session.beginTransaction();
            int registrosModificados = 0;
            
            if (tipoModificacion == 1) {
                // Modificar por campo (masivo)
                System.out.println("\nCAMPOS DISPONIBLES:");
                System.out.println("1) Nombre");
                System.out.print("Elige el campo a modificar: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                if (campo != 1) {
                    System.out.println("❌ Campo no válido");
                    return;
                }
                
                System.out.print("Valor actual a buscar: ");
                String valorAntiguo = reader.nextLine();
                
                System.out.print("Nuevo valor: ");
                String valorNuevo = reader.nextLine();
                
                String hql = "UPDATE Games SET nombre = :nuevo WHERE nombre = :antiguo";
                Query<?> query = session.createQuery(hql);
                query.setParameter("nuevo", valorNuevo);
                query.setParameter("antiguo", valorAntiguo);
                registrosModificados = query.executeUpdate();
                
                System.out.println("\n📝 Se modificarán " + registrosModificados + " registro(s)");
                
            } else if (tipoModificacion == 2) {
                // Modificar juego específico
                System.out.print("\nEscribe el Nombre del juego a modificar: ");
                String nombre = reader.nextLine();
                
                Games game = session.createQuery("FROM Games WHERE nombre = :nombre", Games.class)
                        .setParameter("nombre", nombre)
                        .uniqueResult();
                
                if (game == null) {
                    System.out.println("❌ No se encontró un juego con ese nombre");
                    return;
                }
                
                System.out.println("\nDatos actuales:");
                System.out.println(game);
                
                System.out.println("\n¿Qué campo quieres modificar?");
                System.out.println("1) Nombre");
                System.out.println("2) Tiempo Jugado");
                System.out.print("Opción: ");
                int campoModificar = reader.nextInt();
                reader.nextLine();
                
                switch (campoModificar) {
                    case 1 -> {
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = reader.nextLine();
                        game.setNombre(nuevoNombre);
                    }
                    case 2 -> {
                        System.out.print("Nuevo tiempo jugado (HH:mm:ss): ");
                        String tiempoStr = reader.nextLine();
                        LocalTime nuevoTiempo = LocalTime.parse(tiempoStr, DateTimeFormatter.ofPattern("HH:mm:ss"));
                        game.setTiempoJugado(nuevoTiempo);
                    }
                    default -> {
                        System.out.println("❌ Opción no válida");
                        return;
                    }
                }
                
                session.merge(game);
                registrosModificados = 1;
                
                System.out.println("\n📝 Datos modificados:");
                System.out.println(game);
            }
            
            // Confirmar o cancelar
            System.out.println("\n¿Deseas aplicar los cambios?");
            System.out.println("1) Sí (COMMIT)");
            System.out.println("2) No (ROLLBACK)");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                transaction.commit();
                System.out.println("✅ " + registrosModificados + " registro(s) modificado(s) correctamente");
            } else {
                transaction.rollback();
                System.out.println("❌ Cambios descartados (ROLLBACK)");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al modificar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== MODIFICAR COMPRAS ===============
    private static void modificarCompras(Scanner reader) {
        if (!existeTabla("Compras")) {
            System.out.println("❌ La tabla Compras no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Mostrar todas las compras
            System.out.println("\n========== COMPRAS DISPONIBLES ==========");
            List<Compras> compras = session.createQuery("FROM Compras", Compras.class).list();
            
            if (compras.isEmpty()) {
                System.out.println("❌ No hay compras registradas");
                return;
            }
            
            for (Compras c : compras) {
                Player player = session.get(Player.class, c.getIdPlayer());
                Games game = session.get(Games.class, c.getIdGames());
                
                System.out.println("ID Compra: " + c.getIdCompra());
                System.out.println("  Jugador: " + (player != null ? player.getNick() : "Desconocido"));
                System.out.println("  Juego: " + (game != null ? game.getNombre() : "Desconocido"));
                System.out.println("  Cosa: " + c.getCosa());
                System.out.println("  Precio: " + c.getPrecio());
                System.out.println("  Fecha: " + c.getFechaCompra());
                System.out.println("---");
            }
            System.out.println("=========================================\n");
            
            System.out.println("¿Cómo quieres modificar?");
            System.out.println("1) Modificar por campo (masivo)");
            System.out.println("2) Modificar una compra específica");
            System.out.print("Opción: ");
            int tipoModificacion = reader.nextInt();
            reader.nextLine();
            
            transaction = session.beginTransaction();
            int registrosModificados = 0;
            
            if (tipoModificacion == 1) {
                // Modificar por campo (masivo)
                System.out.println("\nCAMPOS DISPONIBLES:");
                System.out.println("1) Cosa");
                System.out.println("2) Precio");
                System.out.print("Elige el campo a modificar: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                String nombreCampo = switch (campo) {
                    case 1 -> "cosa";
                    case 2 -> "precio";
                    default -> null;
                };
                
                if (nombreCampo == null) {
                    System.out.println("❌ Campo no válido");
                    return;
                }
                
                if (campo == 1) {
                    System.out.print("Valor actual a buscar: ");
                    String valorAntiguo = reader.nextLine();
                    
                    System.out.print("Nuevo valor: ");
                    String valorNuevo = reader.nextLine();
                    
                    String hql = "UPDATE Compras SET cosa = :nuevo WHERE cosa = :antiguo";
                    Query<?> query = session.createQuery(hql);
                    query.setParameter("nuevo", valorNuevo);
                    query.setParameter("antiguo", valorAntiguo);
                    registrosModificados = query.executeUpdate();
                } else {
                    System.out.print("Precio actual a buscar: ");
                    BigDecimal precioAntiguo = new BigDecimal(reader.nextLine());
                    
                    System.out.print("Nuevo precio: ");
                    BigDecimal precioNuevo = new BigDecimal(reader.nextLine());
                    
                    String hql = "UPDATE Compras SET precio = :nuevo WHERE precio = :antiguo";
                    Query<?> query = session.createQuery(hql);
                    query.setParameter("nuevo", precioNuevo);
                    query.setParameter("antiguo", precioAntiguo);
                    registrosModificados = query.executeUpdate();
                }
                
                System.out.println("\n📝 Se modificarán " + registrosModificados + " registro(s)");
                
            } else if (tipoModificacion == 2) {
                // Modificar compra específica por ID
                System.out.print("\nEscribe el ID de la compra a modificar: ");
                int idCompra = reader.nextInt();
                reader.nextLine();
                
                Compras compra = session.get(Compras.class, idCompra);
                
                if (compra == null) {
                    System.out.println("❌ No se encontró una compra con ese ID");
                    return;
                }
                
                Player player = session.get(Player.class, compra.getIdPlayer());
                Games game = session.get(Games.class, compra.getIdGames());
                
                System.out.println("\nDatos actuales:");
                System.out.println("Jugador: " + (player != null ? player.getNick() : "Desconocido"));
                System.out.println("Juego: " + (game != null ? game.getNombre() : "Desconocido"));
                System.out.println("Cosa: " + compra.getCosa());
                System.out.println("Precio: " + compra.getPrecio());
                System.out.println("Fecha: " + compra.getFechaCompra());
                
                System.out.println("\n¿Qué campo quieres modificar?");
                System.out.println("1) Jugador");
                System.out.println("2) Juego");
                System.out.println("3) Cosa");
                System.out.println("4) Precio");
                System.out.println("5) Fecha");
                System.out.print("Opción: ");
                int campoModificar = reader.nextInt();
                reader.nextLine();
                
                switch (campoModificar) {
                    case 1 -> {
                        // Mostrar players disponibles
                        List<Player> players = session.createQuery("FROM Player", Player.class).list();
                        System.out.println("\nJugadores disponibles:");
                        for (Player p : players) {
                            System.out.println("ID: " + p.getIdPlayer() + " - Nick: " + p.getNick());
                        }
                        System.out.print("Escribe el Nick del nuevo jugador: ");
                        String nick = reader.nextLine();
                        Player nuevoPlayer = session.createQuery("FROM Player WHERE nick = :nick", Player.class)
                                .setParameter("nick", nick)
                                .uniqueResult();
                        if (nuevoPlayer != null) {
                            compra.setIdPlayer(nuevoPlayer.getIdPlayer());
                        } else {
                            System.out.println("❌ Jugador no encontrado");
                            return;
                        }
                    }
                    case 2 -> {
                        // Mostrar games disponibles
                        List<Games> gamesList = session.createQuery("FROM Games", Games.class).list();
                        System.out.println("\nJuegos disponibles:");
                        for (Games g : gamesList) {
                            System.out.println("ID: " + g.getIdGames() + " - Nombre: " + g.getNombre());
                        }
                        System.out.print("Escribe el Nombre del nuevo juego: ");
                        String nombreGame = reader.nextLine();
                        Games nuevoGame = session.createQuery("FROM Games WHERE nombre = :nombre", Games.class)
                                .setParameter("nombre", nombreGame)
                                .uniqueResult();
                        if (nuevoGame != null) {
                            compra.setIdGames(nuevoGame.getIdGames());
                        } else {
                            System.out.println("❌ Juego no encontrado");
                            return;
                        }
                    }
                    case 3 -> {
                        System.out.print("Nueva cosa: ");
                        String nuevaCosa = reader.nextLine();
                        compra.setCosa(nuevaCosa);
                    }
                    case 4 -> {
                        System.out.print("Nuevo precio: ");
                        BigDecimal nuevoPrecio = new BigDecimal(reader.nextLine());
                        compra.setPrecio(nuevoPrecio);
                    }
                    case 5 -> {
                        System.out.print("Nueva fecha (yyyy-MM-dd): ");
                        String fechaStr = reader.nextLine();
                        LocalDate nuevaFecha = LocalDate.parse(fechaStr);
                        compra.setFechaCompra(nuevaFecha);
                    }
                    default -> {
                        System.out.println("❌ Opción no válida");
                        return;
                    }
                }
                
                session.merge(compra);
                registrosModificados = 1;
                
                System.out.println("\n📝 Datos modificados:");
                Player playerNuevo = session.get(Player.class, compra.getIdPlayer());
                Games gameNuevo = session.get(Games.class, compra.getIdGames());
                System.out.println("Jugador: " + (playerNuevo != null ? playerNuevo.getNick() : "Desconocido"));
                System.out.println("Juego: " + (gameNuevo != null ? gameNuevo.getNombre() : "Desconocido"));
                System.out.println("Cosa: " + compra.getCosa());
                System.out.println("Precio: " + compra.getPrecio());
                System.out.println("Fecha: " + compra.getFechaCompra());
            }
            
            // Confirmar o cancelar
            System.out.println("\n¿Deseas aplicar los cambios?");
            System.out.println("1) Sí (COMMIT)");
            System.out.println("2) No (ROLLBACK)");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                transaction.commit();
                System.out.println("✅ " + registrosModificados + " registro(s) modificado(s) correctamente");
            } else {
                transaction.rollback();
                System.out.println("❌ Cambios descartados (ROLLBACK)");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al modificar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== VERIFICAR SI EXISTE TABLA ===============
    private static boolean existeTabla(String nombreTabla) {
        Session session = null;
        try {
            session = App.sessionFactory.openSession();
            String sql = "SHOW TABLES LIKE '" + nombreTabla + "'";
            Query<?> query = session.createNativeQuery(sql, Object.class);
            List<?> result = query.list();
            return !result.isEmpty();
        } catch (Exception e) {
            return false;
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}