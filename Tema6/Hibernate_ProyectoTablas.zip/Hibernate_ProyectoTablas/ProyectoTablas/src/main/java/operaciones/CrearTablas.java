package operaciones;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import aplicacion.App;
import indices.Indices;

public class CrearTablas {
    
    public static void ejecutar(Scanner reader) {
        int opcion = 0;
        
        do {
            Indices.MenuCrearTablas();
            opcion = reader.nextInt();
            reader.nextLine();
            
            Session session = null;
            Transaction transaction = null;
            
            try {
                session = App.sessionFactory.openSession();
                transaction = session.beginTransaction();
                
                switch (opcion) {
                    case 1:
                        // Crear tabla Player
                        session.createNativeQuery("""
                            CREATE TABLE IF NOT EXISTS Player (
                                idPlayer INT AUTO_INCREMENT PRIMARY KEY,
                                Nick VARCHAR(45),
                                password VARCHAR(128),
                                email VARCHAR(100)
                            )
                        """, Object.class).executeUpdate();
                        System.out.println("✅ Tabla Player creada");
                        break;
                        
                    case 2:

                        if (!tablaExiste(session, "Player") || !tablaExiste(session, "Games")) {
                            System.out.println("❌ Debes crear primero las tablas Player y Games antes de crear Compras");
                        } else {
                            session.createNativeQuery("""
                                CREATE TABLE IF NOT EXISTS Compras (
                                    idCompra INT AUTO_INCREMENT PRIMARY KEY,
                                    idPlayer INT,
                                    idGames INT,
                                    Cosa VARCHAR(25),
                                    Precio DECIMAL(6,2),
                                    FechaCompra DATE,
                                    FOREIGN KEY (idPlayer) REFERENCES Player(idPlayer),
                                    FOREIGN KEY (idGames) REFERENCES Games(idGames)
                                )
                            """, Object.class).executeUpdate();
                            System.out.println("✅ Tabla Compras creada");
                        }

                        break;
                        
                    case 3:
                        // Crear tabla Games
                        session.createNativeQuery("""
                            CREATE TABLE IF NOT EXISTS Games (
                                idGames INT AUTO_INCREMENT PRIMARY KEY,
                                Nombre VARCHAR(45),
                                tiempoJugado TIME
                            )
                        """, Object.class).executeUpdate();
                        System.out.println("✅ Tabla Games creada");
                        break;
                        
                    case 4:
                        // Crear todas las tablas
                        session.createNativeQuery("""
                            CREATE TABLE IF NOT EXISTS Player (
                                idPlayer INT AUTO_INCREMENT PRIMARY KEY,
                                Nick VARCHAR(45),
                                password VARCHAR(128),
                                email VARCHAR(100)
                            )
                        """, Object.class).executeUpdate();
                        
                        session.createNativeQuery("""
                            CREATE TABLE IF NOT EXISTS Games (
                                idGames INT AUTO_INCREMENT PRIMARY KEY,
                                Nombre VARCHAR(45),
                                tiempoJugado TIME
                            )
                        """, Object.class).executeUpdate();
                        
                        session.createNativeQuery("""
                            CREATE TABLE IF NOT EXISTS Compras (
                                idCompra INT AUTO_INCREMENT PRIMARY KEY,
                                idPlayer INT,
                                idGames INT,
                                Cosa VARCHAR(25),
                                Precio DECIMAL(6,2),
                                FechaCompra DATE,
                                FOREIGN KEY (idPlayer) REFERENCES Player(idPlayer),
                                FOREIGN KEY (idGames) REFERENCES Games(idGames)
                            )
                        """, Object.class).executeUpdate();
                        
                        System.out.println("✅ Las tres tablas han sido creadas");
                        break;
                        
                    case 5:
                        System.out.println("Saliendo de crear tablas...");
                        break;
                        
                    default:
                        System.out.println("❌ Opción no válida");
                        break;
                }
                
                transaction.commit();
                
            } catch (Exception e) {
                if (transaction != null) {
                    transaction.rollback();
                }
                System.err.println("❌ Error: " + e.getMessage());
                e.printStackTrace();
            } finally {
                if (session != null) {
                    session.close();
                }
            }
            
        } while (opcion != 5);
    }
    
    public static boolean tablaExiste(Session session, String tablaNombre) {
        return session.doReturningWork(connection -> {
            ResultSet rs = null;
            try {
                // Obtenemos la metadata de la base de datos
                rs = connection.getMetaData().getTables(null, null, tablaNombre, null);
                return rs.next(); // true si la tabla existe
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            } finally {
                if (rs != null) {
                    try {
                        rs.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }
}

