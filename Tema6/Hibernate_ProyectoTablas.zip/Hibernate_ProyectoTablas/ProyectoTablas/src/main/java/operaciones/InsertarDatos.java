package operaciones;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import aplicacion.App;
import indices.Indices;
import modelos.Compras;
import modelos.Games;
import modelos.Player;

public class InsertarDatos {
    
    public static void ejecutar(Scanner reader) {
        int opcion = 0;
        
        do {
            Indices.MenuInsertarDatos();
            opcion = reader.nextInt();
            reader.nextLine();
            
            switch (opcion) {
                case 1:
                    insertarPlayer(reader);
                    break;
                case 2:
                    insertarCompra(reader);
                    break;
                case 3:
                    insertarGame(reader);
                    break;
                case 4:
                    System.out.println("Saliendo de insertar datos...");
                    break;
                default:
                    System.out.println("❌ Opción no válida");
                    break;
            }
            
        } while (opcion != 4);
    }
    
    // =============== INSERTAR PLAYER ===============
    private static void insertarPlayer(Scanner reader) {
        if (!existeTabla("Player")) {
            System.out.println("❌ La tabla Player no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            System.out.println("\n--- INSERTAR PLAYER ---");
            
            System.out.print("Nick: ");
            String nick = reader.nextLine();
            
            System.out.print("Password: ");
            String password = reader.nextLine();
            
            System.out.print("Email: ");
            String email = reader.nextLine();
            
            Player player = new Player(nick, password, email);
            
            session = App.sessionFactory.openSession();
            transaction = session.beginTransaction();
            
            session.persist(player);
            
            transaction.commit();
            System.out.println("✅ Player insertado correctamente con ID: " + player.getIdPlayer());
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al insertar Player: " + e.getMessage());
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== INSERTAR GAME ===============
    private static void insertarGame(Scanner reader) {
        if (!existeTabla("Games")) {
            System.out.println("❌ La tabla Games no está creada");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            System.out.println("\n--- INSERTAR GAME ---");
            
            System.out.print("Nombre del juego: ");
            String nombre = reader.nextLine();
            
            System.out.print("Tiempo jugado (formato HH:mm:ss): ");
            String tiempoStr = reader.nextLine();
            LocalTime tiempoJugado = LocalTime.parse(tiempoStr, DateTimeFormatter.ofPattern("HH:mm:ss"));
            
            Games game = new Games(nombre, tiempoJugado);
            
            session = App.sessionFactory.openSession();
            transaction = session.beginTransaction();
            
            session.persist(game);
            
            transaction.commit();
            System.out.println("✅ Game insertado correctamente con ID: " + game.getIdGames());
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al insertar Game: " + e.getMessage());
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== INSERTAR COMPRA ===============
    private static void insertarCompra(Scanner reader) {
        if (!existeTabla("Compras")) {
            System.out.println("❌ La tabla Compras no está creada");
            return;
        }
        
        if (!existeTabla("Player") || !existeTabla("Games")) {
            System.out.println("❌ Debes tener creadas las tablas Player y Games primero");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Mostrar listado de Players
            System.out.println("\n--- LISTADO DE PLAYERS ---");
            Query<Player> queryPlayers = session.createQuery("FROM Player", Player.class);
            List<Player> players = queryPlayers.list();
            
            if (players.isEmpty()) {
                System.out.println("❌ No hay jugadores registrados. Inserta primero un Player.");
                return;
            }
            
            for (Player p : players) {
                System.out.println("ID: " + p.getIdPlayer() + " - Nick: " + p.getNick());
            }
            
            System.out.print("\nEscribe el NICK del jugador: ");
            String nickBuscado = reader.nextLine();
            
            Player playerSeleccionado = null;
            for (Player p : players) {
                if (p.getNick().equalsIgnoreCase(nickBuscado)) {
                    playerSeleccionado = p;
                    break;
                }
            }
            
            if (playerSeleccionado == null) {
                System.out.println("❌ No se encontró un jugador con ese nick");
                return;
            }
            
            // Mostrar listado de Games
            System.out.println("\n--- LISTADO DE GAMES ---");
            Query<Games> queryGames = session.createQuery("FROM Games", Games.class);
            List<Games> games = queryGames.list();
            
            if (games.isEmpty()) {
                System.out.println("❌ No hay juegos registrados. Inserta primero un Game.");
                return;
            }
            
            for (Games g : games) {
                System.out.println("ID: " + g.getIdGames() + " - Nombre: " + g.getNombre());
            }
            
            System.out.print("\nEscribe el NOMBRE del juego: ");
            String nombreBuscado = reader.nextLine();
            
            Games gameSeleccionado = null;
            for (Games g : games) {
                if (g.getNombre().equalsIgnoreCase(nombreBuscado)) {
                    gameSeleccionado = g;
                    break;
                }
            }
            
            if (gameSeleccionado == null) {
                System.out.println("❌ No se encontró un juego con ese nombre");
                return;
            }
            
            // Pedir datos de la compra
            System.out.println("\n--- DATOS DE LA COMPRA ---");
            
            System.out.print("Cosa comprada: ");
            String cosa = reader.nextLine();
            
            System.out.print("Precio: ");
            BigDecimal precio = new BigDecimal(reader.nextLine());
            
            System.out.print("Fecha de compra (formato yyyy-MM-dd): ");
            String fechaStr = reader.nextLine();
            LocalDate fechaCompra = LocalDate.parse(fechaStr);
            
            Compras compra = new Compras(
                playerSeleccionado.getIdPlayer(),
                gameSeleccionado.getIdGames(),
                cosa,
                precio,
                fechaCompra
            );
            
            transaction = session.beginTransaction();
            session.persist(compra);
            transaction.commit();
            
            System.out.println("✅ Compra insertada correctamente con ID: " + compra.getIdCompra());
            System.out.println("   Player: " + playerSeleccionado.getNick());
            System.out.println("   Game: " + gameSeleccionado.getNombre());
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("❌ Error al insertar Compra: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== VERIFICAR SI EXISTE TABLA ===============
    private static boolean existeTabla(String nombreTabla) {
        Session session = null;
        try {
            session = App.sessionFactory.openSession();
            String sql = "SHOW TABLES LIKE '" + nombreTabla + "'";
            Query<?> query = session.createNativeQuery(sql, Object.class);
            List<?> result = query.list();
            return !result.isEmpty();
        } catch (Exception e) {
            return false;
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}