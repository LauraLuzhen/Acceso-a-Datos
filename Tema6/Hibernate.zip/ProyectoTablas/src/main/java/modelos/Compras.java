package modelos;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "Compras")
public class Compras {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idCompra")
    private int idCompra;
    
    @Column(name = "idPlayer")
    private int idPlayer;
    
    @Column(name = "idGames")
    private int idGames;
    
    @Column(name = "Cosa", length = 25)
    private String cosa;
    
    @Column(name = "Precio", precision = 6, scale = 2)
    private BigDecimal precio;
    
    @Column(name = "FechaCompra")
    private LocalDate fechaCompra;
    
    // Constructor vacío
    public Compras() {}
    
    // Constructor con parámetros
    public Compras(int idPlayer, int idGames, String cosa, BigDecimal precio, LocalDate fechaCompra) {
        this.idPlayer = idPlayer;
        this.idGames = idGames;
        this.cosa = cosa;
        this.precio = precio;
        this.fechaCompra = fechaCompra;
    }
    
    // Getters y Setters
    public int getIdCompra() {
        return idCompra;
    }
    
    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }
    
    public int getIdPlayer() {
        return idPlayer;
    }
    
    public void setIdPlayer(int idPlayer) {
        this.idPlayer = idPlayer;
    }
    
    public int getIdGames() {
        return idGames;
    }
    
    public void setIdGames(int idGames) {
        this.idGames = idGames;
    }
    
    public String getCosa() {
        return cosa;
    }
    
    public void setCosa(String cosa) {
        this.cosa = cosa;
    }
    
    public BigDecimal getPrecio() {
        return precio;
    }
    
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }
    
    public LocalDate getFechaCompra() {
        return fechaCompra;
    }
    
    public void setFechaCompra(LocalDate fechaCompra) {
        this.fechaCompra = fechaCompra;
    }
    
    @Override
    public String toString() {
        return "Compras [idCompra=" + idCompra + ", idPlayer=" + idPlayer + ", idGames=" + idGames + 
               ", cosa=" + cosa + ", precio=" + precio + ", fechaCompra=" + fechaCompra + "]";
    }
}