package modelos;

import jakarta.persistence.*;
import java.time.LocalTime;

@Entity
@Table(name = "Games")
public class Games {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idGames")
    private int idGames;
    
    @Column(name = "Nombre", length = 45)
    private String nombre;
    
    @Column(name = "tiempoJugado")
    private LocalTime tiempoJugado;
    
    // Constructor vacío
    public Games() {}
    
    // Constructor con parámetros
    public Games(String nombre, LocalTime tiempoJugado) {
        this.nombre = nombre;
        this.tiempoJugado = tiempoJugado;
    }
    
    // Getters y Setters
    public int getIdGames() {
        return idGames;
    }
    
    public void setIdGames(int idGames) {
        this.idGames = idGames;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public LocalTime getTiempoJugado() {
        return tiempoJugado;
    }
    
    public void setTiempoJugado(LocalTime tiempoJugado) {
        this.tiempoJugado = tiempoJugado;
    }
    
    @Override
    public String toString() {
        return "Games [idGames=" + idGames + ", nombre=" + nombre + ", tiempoJugado=" + tiempoJugado + "]";
    }
}