package operaciones;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import aplicacion.App;
import indices.Indices;

public class EliminarTablas {
    
    public static void ejecutar(Scanner reader) {
        int opcion = 0;
        
        do {
            Indices.MenuEliminarTablas();
            opcion = reader.nextInt();
            reader.nextLine();
            
            switch (opcion) {
                case 1:
                    eliminarPlayer(reader);
                    break;
                case 2:
                    eliminarGames(reader);
                    break;
                case 3:
                    eliminarCompras(reader);
                    break;
                case 4:
                    eliminarTodas(reader);
                    break;
                case 5:
                    System.out.println("Saliendo de eliminar tablas...");
                    break;
                default:
                    System.out.println("Opción no válida");
                    break;
            }
            
        } while (opcion != 5);
    }
    
    // =============== ELIMINAR TABLA PLAYER ===============
    private static void eliminarPlayer(Scanner reader) {
        if (!existeTabla("Player")) {
            System.out.println("La tabla Player no existe");
            return;
        }
        
        // Verificar si existe la tabla Compras
        if (existeTabla("Compras")) {
            System.out.println("ERROR: No se puede eliminar la tabla Player");
            System.out.println("Primero debes eliminar la tabla Compras que depende de Player");
            System.out.println("Ve a la opción 3 para eliminar Compras primero");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            transaction = session.beginTransaction();
            
            System.out.println("\n¿Estás seguro de eliminar la tabla Player?");
            System.out.println("Se perderán TODOS los datos de la tabla");
            System.out.println("1) Sí, eliminar");
            System.out.println("2) No, cancelar");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                session.createNativeQuery("DROP TABLE IF EXISTS Player", Object.class).executeUpdate();
                transaction.commit();
                System.out.println("Tabla Player eliminada correctamente");
            } else {
                transaction.rollback();
                System.out.println("Eliminación cancelada");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("Error al eliminar tabla");
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== ELIMINAR TABLA GAMES ===============
    private static void eliminarGames(Scanner reader) {
        if (!existeTabla("Games")) {
            System.out.println("La tabla Games no existe");
            return;
        }
        
        // Verificar si existe la tabla Compras
        if (existeTabla("Compras")) {
            System.out.println("ERROR: No se puede eliminar la tabla Games");
            System.out.println("Primero debes eliminar la tabla Compras que depende de Games");
            System.out.println("Ve a la opción 3 para eliminar Compras primero");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            transaction = session.beginTransaction();
            
            System.out.println("\n¿Estás seguro de eliminar la tabla Games?");
            System.out.println("Se perderán TODOS los datos de la tabla");
            System.out.println("1) Sí, eliminar");
            System.out.println("2) No, cancelar");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                session.createNativeQuery("DROP TABLE IF EXISTS Games", Object.class).executeUpdate();
                transaction.commit();
                System.out.println("Tabla Games eliminada correctamente");
            } else {
                transaction.rollback();
                System.out.println("Eliminación cancelada");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("ERROR Al eliminar tabla");
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== ELIMINAR TABLA COMPRAS ===============
    private static void eliminarCompras(Scanner reader) {
        if (!existeTabla("Compras")) {
            System.out.println("La tabla Compras no existe");
            return;
        }
        
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            transaction = session.beginTransaction();
            
            System.out.println("\n¿Estás seguro de eliminar la tabla Compras?");
            System.out.println("Se perderán TODOS los datos de la tabla");
            System.out.println("1) Sí, eliminar");
            System.out.println("2) No, cancelar");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                session.createNativeQuery("DROP TABLE IF EXISTS Compras", Object.class).executeUpdate();
                transaction.commit();
                System.out.println("Tabla Compras eliminada correctamente");
            } else {
                transaction.rollback();
                System.out.println("Eliminación cancelada");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("Error al eliminar tabla");
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== ELIMINAR TODAS LAS TABLAS ===============
    private static void eliminarTodas(Scanner reader) {
        Session session = null;
        Transaction transaction = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            System.out.println("\nADVERTENCIA ");
            System.out.println("Vas a eliminar TODAS las tablas de la base de datos");
            System.out.println("Se perderán TODOS los datos de:");
            
            if (existeTabla("Player")) System.out.println("  - Player");
            if (existeTabla("Games")) System.out.println("  - Games");
            if (existeTabla("Compras")) System.out.println("  - Compras");
            
            System.out.println("\n¿Estás COMPLETAMENTE seguro?");
            System.out.println("1) Sí, eliminar TODAS");
            System.out.println("2) No, cancelar");
            System.out.print("Opción: ");
            int confirmacion = reader.nextInt();
            reader.nextLine();
            
            if (confirmacion == 1) {
                transaction = session.beginTransaction();
                
                // Orden correcto: primero Compras (tiene FK), luego Player y Games
                if (existeTabla("Compras")) {
                    session.createNativeQuery("DROP TABLE IF EXISTS Compras", Object.class).executeUpdate();
                    System.out.println("Tabla Compras eliminada");
                }
                
                if (existeTabla("Player")) {
                    session.createNativeQuery("DROP TABLE IF EXISTS Player", Object.class).executeUpdate();
                    System.out.println("Tabla Player eliminada");
                }
                
                if (existeTabla("Games")) {
                    session.createNativeQuery("DROP TABLE IF EXISTS Games", Object.class).executeUpdate();
                    System.out.println("Tabla Games eliminada");
                }
                
                transaction.commit();
                System.out.println("\nTodas las tablas han sido eliminadas correctamente");
                
            } else {
                System.out.println("Eliminación cancelada");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.err.println("Error al eliminar tablas");
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // =============== VERIFICAR SI EXISTE TABLA ===============
    private static boolean existeTabla(String nombreTabla) {
        Session session = null;
        try {
            session = App.sessionFactory.openSession();
            String sql = "SHOW TABLES LIKE '" + nombreTabla + "'";
            Query<?> query = session.createNativeQuery(sql, Object.class);
            java.util.List<?> result = query.list();
            return !result.isEmpty();
        } catch (Exception e) {
            return false;
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}