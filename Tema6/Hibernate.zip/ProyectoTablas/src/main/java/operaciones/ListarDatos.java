package operaciones;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.query.Query;

import aplicacion.App;
import indices.Indices;
import modelos.Compras;
import modelos.Games;
import modelos.Player;

public class ListarDatos {
    
    public static void ejecutar(Scanner reader) {
        int opcion = 0;
        
        do {
            Indices.MenuListarTablas();
            opcion = reader.nextInt();
            reader.nextLine();
            
            switch (opcion) {
                case 1:
                    listarPlayer(reader);
                    break;
                case 2:
                    listarCompras(reader);
                    break;
                case 3:
                    listarGames(reader);
                    break;
                case 4:
                    listarTodas(reader);
                    break;
                case 5:
                    System.out.println("Saliendo de listar datos...");
                    break;
                default:
                    System.out.println("Opción no válida");
                    break;
            }
            
        } while (opcion != 5);
    }
    
    // LISTAR PLAYER 
    private static void listarPlayer(Scanner reader) {
        if (!existeTabla("Player")) {
            System.out.println("La tabla Player no está creada");
            return;
        }
        
        System.out.println("\n¿Cómo quieres listar?");
        System.out.println("1) Listar todos");
        System.out.println("2) Listar con filtro");
        System.out.print("Opción: ");
        int opcion = reader.nextInt();
        reader.nextLine();
        
        Session session = null;
        
        try {
            session = App.sessionFactory.openSession();
            String hql = "FROM Player";
            
            if (opcion == 2) {
                System.out.println("\nCAMPOS DISPONIBLES PARA FILTRAR:");
                System.out.println("1) Nick");
                System.out.println("2) email");
                System.out.print("Elige el campo: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                String nombreCampo = switch (campo) {
                    case 1 -> "nick";
                    case 2 -> "email";
                    default -> null;
                };
                
                if (nombreCampo == null) {
                    System.out.println("Campo no válido");
                    return;
                }
                
                System.out.println("\nTIPO DE FILTRO:");
                System.out.println("1) = (igual)");
                System.out.println("2) LIKE %contenido%");
                System.out.print("Opción: ");
                int tipoFiltro = reader.nextInt();
                reader.nextLine();
                
                System.out.print("Valor a buscar: ");
                String valor = reader.nextLine();
                
                hql = construirHQL("Player", nombreCampo, tipoFiltro, valor, false);
            }
            
            Query<Player> query = session.createQuery(hql, Player.class);
            List<Player> players = query.list();
            
            if (players.isEmpty()) {
                System.out.println("\nNo hay registros");
            } else {
                System.out.println("\n========== LISTADO DE PLAYERS ==========");
                for (Player p : players) {
                    System.out.println(p);
                }
                System.out.println("Total: " + players.size() + " registros");
            }
            
        } catch (Exception e) {
            System.err.println("Error al listar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // LISTAR GAMES 
    private static void listarGames(Scanner reader) {
        if (!existeTabla("Games")) {
            System.out.println("La tabla Games no está creada");
            return;
        }
        
        System.out.println("\n¿Cómo quieres listar?");
        System.out.println("1) Listar todos");
        System.out.println("2) Listar con filtro");
        System.out.print("Opción: ");
        int opcion = reader.nextInt();
        reader.nextLine();
        
        Session session = null;
        
        try {
            session = App.sessionFactory.openSession();
            String hql = "FROM Games";
            
            if (opcion == 2) {
                System.out.println("\nCAMPOS DISPONIBLES PARA FILTRAR:");
                System.out.println("1) Nombre");
                System.out.print("Elige el campo: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                String nombreCampo = "nombre";
                
                System.out.println("\nTIPO DE FILTRO:");
                System.out.println("1) = (igual)");
                System.out.println("2) LIKE %contenido%");
                System.out.print("Opción: ");
                int tipoFiltro = reader.nextInt();
                reader.nextLine();
                
                System.out.print("Valor a buscar: ");
                String valor = reader.nextLine();
                
                hql = construirHQL("Games", nombreCampo, tipoFiltro, valor, false);
            }
            
            Query<Games> query = session.createQuery(hql, Games.class);
            List<Games> games = query.list();
            
            if (games.isEmpty()) {
                System.out.println("\nNo hay registros");
            } else {
                System.out.println("\n========== LISTADO DE GAMES ==========");
                for (Games g : games) {
                    System.out.println(g);
                }
                System.out.println("Total: " + games.size() + " registros");
            }
            
        } catch (Exception e) {
            System.err.println("ERROR: Al listar");
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // LISTAR COMPRAS
    private static void listarCompras(Scanner reader) {
        if (!existeTabla("Compras")) {
            System.out.println("La tabla Compras no está creada");
            return;
        }
        
        System.out.println("\n¿Cómo quieres listar?");
        System.out.println("1) Listar todos");
        System.out.println("2) Listar con filtro");
        System.out.print("Opción: ");
        int opcion = reader.nextInt();
        reader.nextLine();
        
        Session session = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            if (opcion == 1) {
                List<Compras> compras = session.createQuery("FROM Compras", Compras.class).list();
                
                if (compras.isEmpty()) {
                    System.out.println("\nNo hay registros");
                } else {
                    System.out.println("\n========== LISTADO DE COMPRAS ==========");
                    for (Compras c : compras) {
                        Player player = session.get(Player.class, c.getIdPlayer());
                        Games game = session.get(Games.class, c.getIdGames());
                        
                        System.out.println("ID Compra: " + c.getIdCompra());
                        System.out.println("  Jugador: " + (player != null ? player.getNick() : "Desconocido"));
                        System.out.println("  Juego: " + (game != null ? game.getNombre() : "Desconocido"));
                        System.out.println("  Cosa: " + c.getCosa());
                        System.out.println("  Precio: " + c.getPrecio());
                        System.out.println("  Fecha: " + c.getFechaCompra());
                        System.out.println("---");
                    }
                    System.out.println("Total: " + compras.size() + " registros");
                }
            } else {
                System.out.println("\nCAMPOS DISPONIBLES PARA FILTRAR:");
                System.out.println("1) Jugador (por Nick)");
                System.out.println("2) Juego (por Nombre)");
                System.out.println("3) Cosa");
                System.out.println("4) Precio");
                System.out.print("Elige el campo: ");
                int campo = reader.nextInt();
                reader.nextLine();
                
                if (campo == 1) {
                    System.out.print("Nick del jugador: ");
                    String nick = reader.nextLine();
                    
                    String hql = "FROM Compras c WHERE c.idPlayer IN (SELECT p.idPlayer FROM Player p WHERE p.nick LIKE '%" + nick + "%')";
                    List<Compras> compras = session.createQuery(hql, Compras.class).list();
                    
                    mostrarComprasConNombres(session, compras);
                    
                } else if (campo == 2) {
                    System.out.print("Nombre del juego: ");
                    String nombre = reader.nextLine();
                    
                    String hql = "FROM Compras c WHERE c.idGames IN (SELECT g.idGames FROM Games g WHERE g.nombre LIKE '%" + nombre + "%')";
                    List<Compras> compras = session.createQuery(hql, Compras.class).list();
                    
                    mostrarComprasConNombres(session, compras);
                    
                } else if (campo == 3 || campo == 4) {
                    String nombreCampo = (campo == 3) ? "cosa" : "precio";
                    boolean esNumerico = (campo == 4);
                    
                    System.out.println("\nTIPO DE FILTRO:");
                    System.out.println("1) = (igual)");
                    System.out.println("2) LIKE %contenido%");
                    System.out.println("3) < (menor que)");
                    System.out.println("4) > (mayor que)");
                    System.out.print("Opción: ");
                    int tipoFiltro = reader.nextInt();
                    reader.nextLine();
                    
                    System.out.print("Valor a buscar: ");
                    String valor = reader.nextLine();
                    
                    String hql = construirHQL("Compras", nombreCampo, tipoFiltro, valor, esNumerico);
                    List<Compras> compras = session.createQuery(hql, Compras.class).list();
                    
                    mostrarComprasConNombres(session, compras);
                }
            }
            
        } catch (Exception e) {
            System.err.println("❌ Error al listar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    // Método auxiliar para mostrar compras con nombres
    private static void mostrarComprasConNombres(Session session, List<Compras> compras) {
        if (compras.isEmpty()) {
            System.out.println("\n❌ No hay registros");
        } else {
            System.out.println("\n========== LISTADO DE COMPRAS ==========");
            for (Compras c : compras) {
                Player player = session.get(Player.class, c.getIdPlayer());
                Games game = session.get(Games.class, c.getIdGames());
                
                System.out.println("ID Compra: " + c.getIdCompra());
                System.out.println("  Jugador: " + (player != null ? player.getNick() : "Desconocido"));
                System.out.println("  Juego: " + (game != null ? game.getNombre() : "Desconocido"));
                System.out.println("  Cosa: " + c.getCosa());
                System.out.println("  Precio: " + c.getPrecio());
                System.out.println("  Fecha: " + c.getFechaCompra());
                System.out.println("---");
            }
            System.out.println("Total: " + compras.size() + " registros");
        }
    }
    
    // =============== LISTAR TODAS ===============
    private static void listarTodas(Scanner reader) {
        System.out.println("\n========================================");
        System.out.println("    LISTADO DE TODAS LAS TABLAS");
        System.out.println("========================================");
        
        Session session = null;
        
        try {
            session = App.sessionFactory.openSession();
            
            // Listar Players
            if (existeTabla("Player")) {
                Query<Player> queryPlayers = session.createQuery("FROM Player", Player.class);
                List<Player> players = queryPlayers.list();
                
                System.out.println("\n--- PLAYERS ---");
                if (players.isEmpty()) {
                    System.out.println("Sin registros");
                } else {
                    for (Player p : players) {
                        System.out.println(p);
                    }
                }
            }
            
            // Listar Games
            if (existeTabla("Games")) {
                Query<Games> queryGames = session.createQuery("FROM Games", Games.class);
                List<Games> games = queryGames.list();
                
                System.out.println("\n--- GAMES ---");
                if (games.isEmpty()) {
                    System.out.println("Sin registros");
                } else {
                    for (Games g : games) {
                        System.out.println(g);
                    }
                }
            }
            
            // Listar Compras
            if (existeTabla("Compras")) {
                List<Compras> compras = session.createQuery("FROM Compras", Compras.class).list();
                
                System.out.println("\n--- COMPRAS ---");
                if (compras.isEmpty()) {
                    System.out.println("Sin registros");
                } else {
                    for (Compras c : compras) {
                        Player player = session.get(Player.class, c.getIdPlayer());
                        Games game = session.get(Games.class, c.getIdGames());
                        
                        System.out.println("ID Compra: " + c.getIdCompra());
                        System.out.println("  Jugador: " + (player != null ? player.getNick() : "Desconocido"));
                        System.out.println("  Juego: " + (game != null ? game.getNombre() : "Desconocido"));
                        System.out.println("  Cosa: " + c.getCosa());
                        System.out.println("  Precio: " + c.getPrecio());
                        System.out.println("  Fecha: " + c.getFechaCompra());
                        System.out.println("---");
                    }
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            if (session != null) {
                session.close();
            }
        }
        
        System.out.println("\n========================================");
    }
    
    // =============== CONSTRUIR HQL CON FILTROS ===============
    private static String construirHQL(String tabla, String campo, int tipoFiltro, String valor, boolean esNumerico) {
        String hql = "FROM " + tabla + " WHERE ";
        
        switch (tipoFiltro) {
            case 1: // Igual
                if (esNumerico) {
                    hql += campo + " = " + valor;
                } else {
                    hql += campo + " = '" + valor + "'";
                }
                break;
            case 2: // LIKE
                hql += campo + " LIKE '%" + valor + "%'";
                break;
            case 3: // Menor que
                if (esNumerico) {
                    hql += campo + " < " + valor;
                } else {
                    hql += campo + " < '" + valor + "'";
                }
                break;
            case 4: // Mayor que
                if (esNumerico) {
                    hql += campo + " > " + valor;
                } else {
                    hql += campo + " > '" + valor + "'";
                }
                break;
            default:
                return "FROM " + tabla;
        }
        
        return hql;
    }
    
    // =============== VERIFICAR SI EXISTE TABLA ===============
    private static boolean existeTabla(String nombreTabla) {
        Session session = null;
        try {
            session = App.sessionFactory.openSession();
            String sql = "SHOW TABLES LIKE '" + nombreTabla + "'";
            Query<?> query = session.createNativeQuery(sql, Object.class);
            List<?> result = query.list();
            return !result.isEmpty();
        } catch (Exception e) {
            return false;
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
}