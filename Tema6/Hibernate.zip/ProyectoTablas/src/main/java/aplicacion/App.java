package aplicacion;

import java.util.Scanner;
import org.hibernate.SessionFactory;
import indices.Indices;
import operaciones.BorrarDatos;
import operaciones.CrearTablas;
import operaciones.EliminarTablas;
import operaciones.InsertarDatos;
import operaciones.ListarDatos;
import operaciones.ModificarDatos;

public class App {

    static Scanner reader = new Scanner(System.in);
    public static SessionFactory sessionFactory;

    public static void main(String[] args) {
        int opcion = 0;

        do {
            Indices.MenuPrincipal();
            opcion = reader.nextInt();
            reader.nextLine();

            switch (opcion) {
            case 1 -> conectar();

            case 2, 3, 4, 5, 6, 7 -> {
                if (sessionFactory == null) {
                    System.out.println("ERROR: Debes conectarte primero a la BBDD");
                } else {
                    switch (opcion) {
                        case 2 -> CrearTablas.ejecutar(reader);
                        case 3 -> InsertarDatos.ejecutar(reader);
                        case 4 -> ListarDatos.ejecutar(reader);
                        case 5 -> ModificarDatos.ejecutar(reader);
                        case 6 -> BorrarDatos.ejecutar(reader);
                        case 7 -> EliminarTablas.ejecutar(reader);
                    }
                }
            }

            case 8 -> {
                System.out.println("Saliendo...");
                if (sessionFactory != null) {
                    desconectar();
                }
            }

            default -> System.out.println("Opción no válida");
        }

        } while (opcion != 8);
        
        reader.close();
    }

    public static void conectar() {
        try {
            sessionFactory = HibernateUtil.getSessionFactory();
            if (sessionFactory != null) {
                System.out.println("Conexión exitosa con Hibernate");
            }
        } catch (Exception e) {
            System.err.println("ERROR: al conectarse con Hibernate");
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public static void desconectar() {
        HibernateUtil.shutdown();
        System.out.println("Conexión cerrada");
    }
}